var a = confirm("Are you sure??");
 if(a==true)  
{
alert("User Accepted");
}
else{
alert("User Cancled");
}